- EXP_11.m ~ EXP_14.m ��the experiments presented in Table 2-7, the comparision between CCI and MHPC

- EXP_21.m ~ EXP_22.m ��the experiments presented in Table 8 and 10

- EXP_31.m��the experiment presented in Fig.5

  Note that, one can change "rand('state',1)" to produce other results

  *** one should add algorithm to path
        